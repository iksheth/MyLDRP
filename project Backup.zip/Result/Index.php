<?php
/**
 * Created by PhpStorm.
 * User: karansheth
 * Date: 13/04/16
 * Time: 8:48 AM
 */

$a = 10;
echo "hello";
$a="apple";
echo $a;
echo phpinfo();
?>