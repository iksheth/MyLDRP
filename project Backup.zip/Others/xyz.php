<?php

/**
 * Created by PhpStorm.
 * User: karansheth
 * Date: 13/04/16
 * Time: 6:13 PM
 */
class xyz
{
    function apple()
    {
        echo "HI";
    }
}