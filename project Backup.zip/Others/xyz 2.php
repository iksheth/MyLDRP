<?php

/**
 * Created by PhpStorm.
 * User: karansheth
 * Date: 13/04/16
 * Time: 5:43 PM
 */
class xyz
{

    function a()
    {
        echo " Hello ";
    }
}