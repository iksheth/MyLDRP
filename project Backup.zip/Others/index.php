<?php
/**
 * Created by PhpStorm.
 * User: karansheth
 * Date: 13/04/16
 * Time: 6:08 PM
 */
include 'xyz.php';

$a = new xyz();
$a->apple();

echo "hi";