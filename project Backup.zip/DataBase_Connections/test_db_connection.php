<?php
/**
 * Created by PhpStorm.
 * User: karansheth
 * Date: 30/04/16
 * Time: 10:55 AM
 */


require_once($_SERVER['DOCUMENT_ROOT'] . "/DataBase_Connections/db.php");
$dbcon = new \createCon();
